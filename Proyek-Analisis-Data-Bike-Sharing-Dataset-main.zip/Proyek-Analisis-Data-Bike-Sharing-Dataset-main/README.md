# Dicoding Analisis Data - Bike Sharing Dataset

## Setup Environment - Anaconda

conda create --name main-ds python=3.12.8

conda activate main-ds

pip install -r requirements.txt 

## Setup Environment

pip install -r requirements.txt

## Streamlit check

streamlit hello

## Run streamlit app

streamlit run dashboard.py

